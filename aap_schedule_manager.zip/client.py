"""
AAP v2 REST client — schedule operations only.
Auth: username + password (Basic Auth).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Optional

import requests
from requests.auth import HTTPBasicAuth

from app.core.config import get_settings

log = logging.getLogger("aap.client")


@dataclass
class SchedulePayload:
    """Represents the data sent to the AAP schedule API."""
    name: str
    rrule: str
    description: str = ""
    enabled: bool = True
    extra_data: dict = field(default_factory=dict)
    limit: Optional[str] = None
    job_tags: Optional[str] = None
    skip_tags: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "name": self.name,
            "rrule": self.rrule,
            "description": self.description,
            "enabled": self.enabled,
        }
        if self.extra_data:
            d["extra_data"] = self.extra_data
        if self.limit:
            d["limit"] = self.limit
        if self.job_tags:
            d["job_tags"] = self.job_tags
        if self.skip_tags:
            d["skip_tags"] = self.skip_tags
        return d


class AAPClient:
    """Thin AAP v2 REST wrapper — schedule-scoped methods only."""

    def __init__(
        self,
        base_url: str,
        username: str,
        password: str,
        verify_ssl: bool = True,
        timeout: int = 30,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._timeout = timeout
        self._s = requests.Session()
        self._s.auth = HTTPBasicAuth(username, password)
        self._s.headers["Content-Type"] = "application/json"
        self._s.verify = verify_ssl

    # ── low-level ───────────────────────────────────────────────────────────

    def _url(self, path: str) -> str:
        return f"{self._base}/api/v2/{path.lstrip('/')}"

    def _get(self, path: str, params: dict | None = None) -> dict:
        r = self._s.get(self._url(path), params=params, timeout=self._timeout)
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, body: dict) -> dict:
        r = self._s.post(self._url(path), json=body, timeout=self._timeout)
        r.raise_for_status()
        return r.json()

    def _patch(self, path: str, body: dict) -> dict:
        r = self._s.patch(self._url(path), json=body, timeout=self._timeout)
        r.raise_for_status()
        return r.json()

    def _delete(self, path: str) -> None:
        r = self._s.delete(self._url(path), timeout=self._timeout)
        r.raise_for_status()

    # ── job template ────────────────────────────────────────────────────────

    def get_job_template(self, jt_id: int) -> dict:
        return self._get(f"job_templates/{jt_id}/")

    # ── schedules ───────────────────────────────────────────────────────────

    def list_schedules(self, jt_id: int) -> list[dict]:
        return self._get(f"job_templates/{jt_id}/schedules/").get("results", [])

    def get_schedule(self, schedule_id: int) -> dict:
        return self._get(f"schedules/{schedule_id}/")

    def create_schedule(self, jt_id: int, payload: SchedulePayload) -> dict:
        log.info("AAP create schedule %r on JT %s", payload.name, jt_id)
        return self._post(f"job_templates/{jt_id}/schedules/", payload.to_dict())

    def update_schedule(self, schedule_id: int, updates: dict) -> dict:
        log.info("AAP patch schedule %s fields=%s", schedule_id, list(updates))
        return self._patch(f"schedules/{schedule_id}/", updates)

    def delete_schedule(self, schedule_id: int) -> None:
        log.warning("AAP delete schedule %s", schedule_id)
        self._delete(f"schedules/{schedule_id}/")


# ── FastAPI dependency ───────────────────────────────────────────────────────

def get_aap_client() -> AAPClient:
    s = get_settings()
    return AAPClient(
        base_url=s.aap_url,
        username=s.aap_username,
        password=s.aap_password,
        verify_ssl=s.aap_verify_ssl,
        timeout=s.aap_timeout,
    )

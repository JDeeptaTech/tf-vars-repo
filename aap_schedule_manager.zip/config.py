"""
Settings — all values driven by environment variables.
In OpenShift the AAP password and DB URL are injected by Vault Agent sidecar.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ── App ──────────────────────────────────────────────────────────────────
    app_name: str = "AAP Job Schedule Manager"
    app_version: str = "1.0.0"
    debug: bool = False

    # ── Database (Vault Agent injects DATABASE_URL) ──────────────────────────
    database_url: str = (
        "postgresql+asyncpg://vmuser:vmpass@localhost:5432/vmplatform"
    )
    db_pool_size: int = 10
    db_max_overflow: int = 20
    db_pool_timeout: int = 30

    # ── AAP credentials (Vault Agent injects AAP_PASSWORD) ───────────────────
    aap_url: str = "https://aap.your-company.com"
    aap_username: str = "admin"
    aap_password: str = "change-me"
    aap_verify_ssl: bool = True
    aap_timeout: int = 30


@lru_cache
def get_settings() -> Settings:
    return Settings()

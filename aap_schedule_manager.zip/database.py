"""
ORM model  platform.aap_job_schedules
Async SQLAlchemy 2.0 + asyncpg.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import AsyncGenerator

from sqlalchemy import Boolean, DateTime, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.ext.asyncio import (
    AsyncEngine, AsyncSession,
    async_sessionmaker, create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.sql import func

from app.core.config import get_settings


class Base(DeclarativeBase):
    pass


class JobSchedule(Base):
    __tablename__ = "aap_job_schedules"
    __table_args__ = (
        UniqueConstraint("name", "job_template_id", name="uq_sched_name_jt"),
        Index("ix_sched_jt",         "job_template_id"),
        Index("ix_sched_status",      "sync_status"),
        Index("ix_sched_enabled",     "enabled"),
        Index("ix_sched_created_by",  "created_by"),
        {"schema": "platform"},
    )

    # ── identity ──────────────────────────────────────────────────────────
    id: Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str]      = mapped_column(String(128),  nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ── AAP references ────────────────────────────────────────────────────
    job_template_id:   Mapped[int]       = mapped_column(Integer,     nullable=False)
    job_template_name: Mapped[str | None] = mapped_column(String(256), nullable=True)
    aap_schedule_id:   Mapped[int | None] = mapped_column(Integer,     nullable=True)

    # ── schedule definition ───────────────────────────────────────────────
    rrule:       Mapped[str]  = mapped_column(Text,      nullable=False)
    freq_type:   Mapped[str]  = mapped_column(String(16), nullable=False)  # once|DAILY|WEEKLY…
    timezone:    Mapped[str]  = mapped_column(String(64), nullable=False, default="Europe/London")
    enabled:     Mapped[bool] = mapped_column(Boolean,    nullable=False, default=True)

    # ── playbook overrides ────────────────────────────────────────────────
    extra_data: Mapped[dict]       = mapped_column(JSONB,       nullable=False, server_default="{}")
    limit:      Mapped[str | None] = mapped_column(String(256), nullable=True)
    job_tags:   Mapped[str | None] = mapped_column(String(512), nullable=True)
    skip_tags:  Mapped[str | None] = mapped_column(String(512), nullable=True)

    # ── sync tracking ─────────────────────────────────────────────────────
    sync_status:    Mapped[str]            = mapped_column(String(16), nullable=False, default="pending")
    last_synced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    next_run:       Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # ── audit ─────────────────────────────────────────────────────────────
    created_by: Mapped[str]      = mapped_column(String(128),          nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now())


# ── engine + session ─────────────────────────────────────────────────────────

_engine:  AsyncEngine | None = None
_factory: async_sessionmaker[AsyncSession] | None = None


def get_engine() -> AsyncEngine:
    global _engine
    if _engine is None:
        s = get_settings()
        _engine = create_async_engine(
            s.database_url,
            pool_size=s.db_pool_size,
            max_overflow=s.db_max_overflow,
            pool_timeout=s.db_pool_timeout,
            pool_pre_ping=True,
            echo=s.debug,
        )
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    global _factory
    if _factory is None:
        _factory = async_sessionmaker(
            bind=get_engine(), expire_on_commit=False, autoflush=False
        )
    return _factory


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with get_session_factory()() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise

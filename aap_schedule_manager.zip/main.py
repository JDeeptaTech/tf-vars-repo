"""
FastAPI application factory — AAP Job Schedule Manager.
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request, status
from fastapi.exceptions import HTTPException, RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError

from app.api.v1.schedules import router as schedule_router
from app.core.config import get_settings
from app.db.database import get_engine
from app.schemas.schedule import ErrorResponse

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
log = logging.getLogger("app")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    log.info("AAP Schedule API starting up")
    yield
    await get_engine().dispose()
    log.info("Shutdown complete")


# ── helpers ──────────────────────────────────────────────────────────────────

def _err(code: int, message: str, detail: str | None = None) -> JSONResponse:
    return JSONResponse(
        status_code=code,
        content=ErrorResponse(message=message, detail=detail).model_dump(),
    )


# ── factory ───────────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    s = get_settings()

    app = FastAPI(
        title=s.app_name,
        version=s.app_version,
        debug=s.debug,
        lifespan=lifespan,
        description="""
## AAP Job Schedule Manager

Manage Ansible Automation Platform job schedules through a clean REST API.

### Features
- **Create** one-time or recurring schedules without writing raw rrule strings
- **Read** individual schedules or browse all with filters and pagination
- **Update** any field with PATCH semantics — only send what you want to change
- **Delete** schedules safely — removed from AAP, retained locally for audit
- **Sync** — retry failed pushes after an AAP outage without re-submitting the form

### Sync status lifecycle
```
pending ──► synced ──► deleted
   │                      ▲
   └──► failed ──────────►┘  (via POST /sync)
```

### Auth
All endpoints require the AAP credentials set via environment variables
(`AAP_URL`, `AAP_USERNAME`, `AAP_PASSWORD`). In OpenShift these are
injected by the Vault Agent sidecar.
        """,
        openapi_tags=[
            {
                "name": "AAP Job Schedules",
                "description": "Full CRUD for AAP job template schedules",
            },
        ],
    )

    app.include_router(schedule_router, prefix="/api/v1")

    # ── exception handlers ───────────────────────────────────────────────────

    @app.exception_handler(HTTPException)
    async def http_exc(req: Request, exc: HTTPException) -> JSONResponse:
        return _err(exc.status_code, str(exc.detail))

    @app.exception_handler(RequestValidationError)
    async def validation_exc(req: Request, exc: RequestValidationError) -> JSONResponse:
        errors = "; ".join(
            f"{' → '.join(str(l) for l in e['loc'])}: {e['msg']}"
            for e in exc.errors()
        )
        return _err(status.HTTP_422_UNPROCESSABLE_ENTITY, "Request validation failed", errors)

    @app.exception_handler(IntegrityError)
    async def integrity_exc(req: Request, exc: IntegrityError) -> JSONResponse:
        return _err(status.HTTP_409_CONFLICT, "Database conflict", str(exc.orig))

    @app.exception_handler(Exception)
    async def generic_exc(req: Request, exc: Exception) -> JSONResponse:
        log.exception("Unhandled exception on %s %s", req.method, req.url.path)
        return _err(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            "Internal server error",
            str(exc) if s.debug else None,
        )

    # ── health ───────────────────────────────────────────────────────────────

    @app.get("/healthz", include_in_schema=False)
    async def health() -> dict:
        return {"status": "ok", "version": s.app_version}

    return app


app = create_app()

"""
iCalendar RRULE helpers.

AAP requires schedules in iCal RRULE format, not standard cron syntax.
These functions build the correct string from friendly typed parameters
so callers never need to write raw rrule strings.

Format:
  DTSTART;TZID=<timezone>:<YYYYMMDDTHHmmss>
  RRULE:FREQ=<freq>;INTERVAL=<n>[;<optional-parts>]
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo


def rrule_once(dt: datetime, tz_name: str = "Europe/London") -> str:
    """
    Single one-time execution.
    Uses COUNT=1 — AAP auto-disables the schedule after it fires.
    """
    local = dt.astimezone(ZoneInfo(tz_name))
    return (
        f"DTSTART;TZID={tz_name}:{local.strftime('%Y%m%dT%H%M%S')}\n"
        "RRULE:FREQ=MINUTELY;INTERVAL=1;COUNT=1"
    )


def rrule_recurring(
    dt: datetime,
    freq: str = "DAILY",
    interval: int = 1,
    tz_name: str = "Europe/London",
    count: Optional[int] = None,
    until: Optional[datetime] = None,
    byday: Optional[str] = None,
    byhour: Optional[int] = None,
    byminute: Optional[int] = None,
) -> str:
    """
    Recurring schedule — cron-like using iCalendar RRULE.

    freq    : MINUTELY | HOURLY | DAILY | WEEKLY | MONTHLY
    byday   : "MO,TU,WE,TH,FR"  (weekdays only)
    count   : stop after N runs
    until   : stop at this datetime (mutually exclusive with count)
    """
    local = dt.astimezone(ZoneInfo(tz_name))
    parts = [f"FREQ={freq}", f"INTERVAL={interval}"]
    if count is not None:
        parts.append(f"COUNT={count}")
    if until is not None:
        parts.append(f"UNTIL={until.strftime('%Y%m%dT%H%M%SZ')}")
    if byday:
        parts.append(f"BYDAY={byday}")
    if byhour is not None:
        parts.append(f"BYHOUR={byhour}")
    if byminute is not None:
        parts.append(f"BYMINUTE={byminute}")
    return (
        f"DTSTART;TZID={tz_name}:{local.strftime('%Y%m%dT%H%M%S')}\n"
        f"RRULE:{';'.join(parts)}"
    )

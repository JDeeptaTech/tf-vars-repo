"""
Pydantic v2 schemas for AAP Job Schedule CRUD.

Every request schema carries openapi_examples so the Swagger UI
shows realistic, ready-to-copy payloads for every common scenario.
"""
from __future__ import annotations

import math
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any, Generic, Optional, TypeVar
from uuid import UUID

from pydantic import BaseModel, Field, model_validator


# ── Enumerations ─────────────────────────────────────────────────────────────

class FreqType(StrEnum):
    ONCE     = "once"
    HOURLY   = "HOURLY"
    DAILY    = "DAILY"
    WEEKLY   = "WEEKLY"
    MONTHLY  = "MONTHLY"


class SyncStatus(StrEnum):
    PENDING = "pending"
    SYNCED  = "synced"
    FAILED  = "failed"
    DELETED = "deleted"


# ── Timing sub-schemas ────────────────────────────────────────────────────────

class OnceParams(BaseModel):
    """Run the job exactly once at a specific date and time."""
    run_at:   datetime = Field(..., description="UTC datetime to fire the job")
    timezone: str      = Field("Europe/London", description="IANA timezone for display")

    model_config = {
        "json_schema_extra": {
            "example": {
                "run_at": "2025-07-01T02:00:00Z",
                "timezone": "Europe/London",
            }
        }
    }


class RecurringParams(BaseModel):
    """Cron-like recurring schedule — expressed as typed fields, not raw rrule."""

    freq:      FreqType       = Field(FreqType.DAILY,  description="How often the schedule repeats")
    interval:  int            = Field(1, ge=1, le=1000, description="Every N units of freq")
    timezone:  str            = Field("Europe/London",  description="IANA timezone")
    start_dt:  datetime       = Field(
        default_factory=lambda: datetime.now(tz=timezone.utc),
        description="First occurrence (defaults to now)",
    )
    count:     Optional[int]      = Field(None, ge=1,     description="Stop after N runs (exclusive with until)")
    until:     Optional[datetime] = Field(None,           description="Stop at this UTC datetime (exclusive with count)")
    byday:     Optional[str]      = Field(None,           description='Days filter e.g. "MO,TU,WE,TH,FR"')
    byhour:    Optional[int]      = Field(None, ge=0, le=23)
    byminute:  Optional[int]      = Field(None, ge=0, le=59)

    @model_validator(mode="after")
    def _exclusive(self) -> "RecurringParams":
        if self.count and self.until:
            raise ValueError("Use either 'count' or 'until', not both")
        return self

    model_config = {
        "json_schema_extra": {
            "example": {
                "freq": "WEEKLY",
                "interval": 1,
                "timezone": "Europe/London",
                "start_dt": "2025-06-01T02:00:00Z",
                "byday": "MO,TU,WE,TH,FR",
            }
        }
    }


# ── CREATE ────────────────────────────────────────────────────────────────────

class ScheduleCreate(BaseModel):
    """
    Create a new schedule on an AAP Job Template.

    Provide **exactly one** of `once` or `recurring` to define the timing.
    The iCalendar `rrule` is built server-side — no raw rrule strings required.
    """

    name:              str            = Field(..., min_length=3, max_length=128)
    job_template_id:   int            = Field(..., description="Numeric AAP Job Template ID")
    job_template_name: Optional[str]  = Field(None, description="Human-readable JT name (informational)")
    description:       Optional[str]  = Field(None, max_length=500)
    enabled:           bool           = Field(True, description="Activate immediately on creation")
    created_by:        str            = Field(..., description="Username of the person creating this schedule")
    timezone:          str            = Field("Europe/London", description="Default timezone applied to timing params")

    # ── timing (exactly one required) ────────────────────────────────────
    once:      Optional[OnceParams]      = None
    recurring: Optional[RecurringParams] = None

    # ── playbook overrides ────────────────────────────────────────────────
    extra_data: dict          = Field(default_factory=dict,  description="Extra vars passed to the playbook at runtime")
    limit:      Optional[str] = Field(None,                  description="Host limit pattern, e.g. 'dev_servers'")
    job_tags:   Optional[str] = Field(None,                  description="Comma-separated Ansible tags to run")
    skip_tags:  Optional[str] = Field(None,                  description="Comma-separated Ansible tags to skip")

    @model_validator(mode="after")
    def _exactly_one_type(self) -> "ScheduleCreate":
        if not self.once and not self.recurring:
            raise ValueError("Provide exactly one of 'once' or 'recurring'")
        if self.once and self.recurring:
            raise ValueError("Provide only one of 'once' or 'recurring', not both")
        return self

    model_config = {
        "openapi_extra": {},
        "json_schema_extra": {
            "examples": {
                "nightly_weekday": {
                    "summary": "Nightly weekday compliance check (Mon–Fri 02:00 London)",
                    "value": {
                        "name": "nightly-compliance-check",
                        "job_template_id": 42,
                        "job_template_name": "VM Compliance Check",
                        "description": "Runs Ansible compliance playbook every weekday at 02:00 London time",
                        "enabled": True,
                        "created_by": "pradeep",
                        "timezone": "Europe/London",
                        "recurring": {
                            "freq": "WEEKLY",
                            "interval": 1,
                            "timezone": "Europe/London",
                            "start_dt": "2025-07-01T02:00:00Z",
                            "byday": "MO,TU,WE,TH,FR",
                        },
                        "extra_data": {
                            "environment": "production",
                            "check_mode": True,
                            "notify_slack": True,
                        },
                        "job_tags": "compliance,audit",
                    },
                },
                "one_time_vm_build": {
                    "summary": "One-time VM build — fires once 10 minutes from now",
                    "value": {
                        "name": "one-time-myvm-dev-01-build",
                        "job_template_id": 17,
                        "job_template_name": "VM Build Playbook",
                        "description": "Single run to provision myvm-dev-01",
                        "enabled": True,
                        "created_by": "pradeep",
                        "timezone": "Europe/London",
                        "once": {
                            "run_at": "2025-07-01T14:30:00Z",
                            "timezone": "Europe/London",
                        },
                        "extra_data": {
                            "vm_name": "myvm-dev-01",
                            "environment": "dev",
                            "cpu": 4,
                            "memory_gb": 8,
                            "requestor": "pradeep",
                        },
                        "limit": "dev_hosts",
                    },
                },
                "patch_window": {
                    "summary": "Monthly Saturday patch window — 22:00, max 12 runs",
                    "value": {
                        "name": "monthly-saturday-patch",
                        "job_template_id": 55,
                        "job_template_name": "OS Patch Playbook",
                        "description": "Monthly patching window — 1st Saturday of each month at 22:00",
                        "enabled": False,
                        "created_by": "pradeep",
                        "timezone": "Europe/London",
                        "recurring": {
                            "freq": "MONTHLY",
                            "interval": 1,
                            "timezone": "Europe/London",
                            "start_dt": "2025-07-05T22:00:00Z",
                            "byday": "SA",
                            "count": 12,
                        },
                        "extra_data": {
                            "patch_group": "wave_1",
                            "reboot_allowed": True,
                            "notify_teams": True,
                        },
                        "skip_tags": "pre_checks",
                    },
                },
                "six_hourly_rotation": {
                    "summary": "Every 6 hours — rolling config drift check",
                    "value": {
                        "name": "6hr-config-drift-check",
                        "job_template_id": 33,
                        "job_template_name": "Config Drift Playbook",
                        "description": "Runs every 6 hours to detect configuration drift",
                        "enabled": True,
                        "created_by": "pradeep",
                        "timezone": "UTC",
                        "recurring": {
                            "freq": "HOURLY",
                            "interval": 6,
                            "timezone": "UTC",
                            "start_dt": "2025-07-01T00:00:00Z",
                        },
                        "extra_data": {
                            "alert_on_drift": True,
                            "remediate": False,
                        },
                    },
                },
                "day2_vm_snapshot": {
                    "summary": "Daily VM snapshot — every day at midnight",
                    "value": {
                        "name": "daily-vm-snapshot",
                        "job_template_id": 28,
                        "job_template_name": "VM Day-2 Snapshot",
                        "description": "Takes a snapshot of all running VMs daily at midnight UTC",
                        "enabled": True,
                        "created_by": "pradeep",
                        "timezone": "UTC",
                        "recurring": {
                            "freq": "DAILY",
                            "interval": 1,
                            "timezone": "UTC",
                            "start_dt": "2025-07-01T00:00:00Z",
                        },
                        "extra_data": {
                            "snapshot_type": "full",
                            "retain_days": 7,
                            "environment": "production",
                        },
                        "limit": "prod_vms",
                    },
                },
            }
        },
    }


# ── UPDATE ────────────────────────────────────────────────────────────────────

class ScheduleUpdate(BaseModel):
    """
    Partially update a schedule — PATCH semantics.
    Only provided fields are changed. Omit any field to leave it unchanged.
    Providing `once` or `recurring` rebuilds the entire rrule.
    """

    description: Optional[str]           = Field(None, max_length=500)
    enabled:     Optional[bool]           = None
    once:        Optional[OnceParams]     = None
    recurring:   Optional[RecurringParams] = None
    extra_data:  Optional[dict]           = None
    limit:       Optional[str]            = None
    job_tags:    Optional[str]            = None
    skip_tags:   Optional[str]            = None

    @model_validator(mode="after")
    def _validate(self) -> "ScheduleUpdate":
        if self.once and self.recurring:
            raise ValueError("Provide only one of 'once' or 'recurring'")
        if all(v is None for v in self.model_dump().values()):
            raise ValueError("At least one field must be provided")
        return self

    model_config = {
        "json_schema_extra": {
            "examples": {
                "reschedule_to_daily": {
                    "summary": "Change from weekly to daily and update extra vars",
                    "value": {
                        "recurring": {
                            "freq": "DAILY",
                            "interval": 1,
                            "timezone": "Europe/London",
                            "start_dt": "2025-07-01T03:00:00Z",
                        },
                        "description": "Updated — now runs daily at 03:00 London",
                        "extra_data": {
                            "environment": "production",
                            "notify_slack": True,
                            "check_mode": False,
                        },
                    },
                },
                "pause_schedule": {
                    "summary": "Disable (pause) a schedule without deleting it",
                    "value": {"enabled": False},
                },
                "resume_schedule": {
                    "summary": "Re-enable a previously paused schedule",
                    "value": {"enabled": True},
                },
                "update_tags": {
                    "summary": "Change which Ansible tags run",
                    "value": {
                        "job_tags": "compliance,audit,reporting",
                        "skip_tags": "slow_checks",
                    },
                },
                "update_extra_vars": {
                    "summary": "Override playbook variables without changing timing",
                    "value": {
                        "extra_data": {
                            "environment": "uat",
                            "notify_teams": True,
                            "patch_group": "wave_2",
                        }
                    },
                },
                "change_host_limit": {
                    "summary": "Restrict execution to a specific host group",
                    "value": {"limit": "uat_servers"},
                },
                "reschedule_one_time": {
                    "summary": "Move a one-time schedule to a new datetime",
                    "value": {
                        "once": {
                            "run_at": "2025-07-15T09:00:00Z",
                            "timezone": "Europe/London",
                        },
                        "description": "Rescheduled from 01 Jul to 15 Jul at 09:00",
                    },
                },
            }
        }
    }


# ── RESPONSE ──────────────────────────────────────────────────────────────────

class ScheduleResponse(BaseModel):
    """Full schedule representation — returned by all endpoints."""

    model_config = {"from_attributes": True}

    id:                UUID
    name:              str
    description:       Optional[str]
    job_template_id:   int
    job_template_name: Optional[str]
    aap_schedule_id:   Optional[int]
    rrule:             str
    freq_type:         FreqType
    timezone:          str
    enabled:           bool
    sync_status:       SyncStatus
    extra_data:        dict
    limit:             Optional[str]
    job_tags:          Optional[str]
    skip_tags:         Optional[str]
    next_run:          Optional[datetime]
    created_by:        str
    created_at:        datetime
    updated_at:        datetime
    last_synced_at:    Optional[datetime]


# ── RESPONSE ENVELOPE ─────────────────────────────────────────────────────────

T = TypeVar("T")


class PaginationMeta(BaseModel):
    page:        int
    page_size:   int
    total:       int
    total_pages: int

    @classmethod
    def build(cls, total: int, page: int, page_size: int) -> "PaginationMeta":
        return cls(
            page=page,
            page_size=page_size,
            total=total,
            total_pages=math.ceil(total / page_size) if page_size else 0,
        )


class APIResponse(BaseModel, Generic[T]):
    success: bool                    = True
    data:    Optional[T]             = None
    message: Optional[str]           = None
    meta:    Optional[PaginationMeta] = None

    @classmethod
    def ok(
        cls,
        data: T,
        message: Optional[str] = None,
        meta: Optional[PaginationMeta] = None,
    ) -> "APIResponse[T]":
        return cls(success=True, data=data, message=message, meta=meta)


class ErrorResponse(BaseModel):
    success: bool           = False
    data:    None           = None
    message: str            = ""
    detail:  Optional[str]  = None


# ── FILTER (query parameters) ─────────────────────────────────────────────────

class ScheduleFilter(BaseModel):
    """Query parameters for GET /schedules."""
    job_template_id: Optional[int]        = None
    freq_type:       Optional[FreqType]   = None
    enabled:         Optional[bool]       = None
    sync_status:     Optional[SyncStatus] = None
    created_by:      Optional[str]        = None
    name_contains:   Optional[str]        = Field(None, description="Case-insensitive substring match on name")
    page:            int                  = Field(1,  ge=1)
    page_size:       int                  = Field(20, ge=1, le=100)

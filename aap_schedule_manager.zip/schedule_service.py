"""
Schedule service — orchestrates local DB writes and AAP API calls.

Flow for every mutating operation:
  1.  Validate (uniqueness, state guards)
  2.  Write to local DB  (sync_status = pending)
  3.  Push to AAP
  4.  Stamp local record with AAP ID + sync_status = synced
  5.  On AAP failure → sync_status = failed  (retry via POST /sync)
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

import requests as _requests
from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.aap.client import AAPClient, SchedulePayload
from app.aap.rrule import rrule_once, rrule_recurring
from app.db.database import JobSchedule
from app.schemas.schedule import (
    FreqType,
    ScheduleCreate,
    ScheduleFilter,
    ScheduleUpdate,
    SyncStatus,
)

log = logging.getLogger("schedule.service")


class ScheduleService:

    def __init__(self, db: AsyncSession, aap: AAPClient) -> None:
        self.db  = db
        self.aap = aap

    # ── helpers ──────────────────────────────────────────────────────────────

    def _build_rrule(self, payload: ScheduleCreate | ScheduleUpdate) -> Optional[str]:
        if payload.once:
            return rrule_once(payload.once.run_at, tz_name=payload.once.timezone)
        if payload.recurring:
            r = payload.recurring
            return rrule_recurring(
                dt=r.start_dt,
                freq=r.freq.value if r.freq != FreqType.ONCE else "DAILY",
                interval=r.interval,
                tz_name=r.timezone,
                count=r.count,
                until=r.until,
                byday=r.byday,
                byhour=r.byhour,
                byminute=r.byminute,
            )
        return None

    async def _get_or_404(self, sid: uuid.UUID) -> JobSchedule:
        rec = await self.db.get(JobSchedule, sid)
        if not rec:
            raise HTTPException(status.HTTP_404_NOT_FOUND, f"Schedule {sid} not found")
        return rec

    def _stamp_aap(self, rec: JobSchedule, aap_resp: dict) -> None:
        rec.aap_schedule_id = aap_resp.get("id")
        rec.sync_status     = SyncStatus.SYNCED
        rec.last_synced_at  = datetime.now(tz=timezone.utc)
        raw = aap_resp.get("next_run")
        if raw:
            rec.next_run = (
                datetime.fromisoformat(raw.replace("Z", "+00:00"))
                if isinstance(raw, str) else raw
            )

    def _to_aap_payload(self, rec: JobSchedule) -> SchedulePayload:
        return SchedulePayload(
            name=rec.name, rrule=rec.rrule,
            description=rec.description or "", enabled=rec.enabled,
            extra_data=rec.extra_data or {}, limit=rec.limit,
            job_tags=rec.job_tags, skip_tags=rec.skip_tags,
        )

    def _aap_502(self, exc: Exception, msg: str) -> HTTPException:
        detail = str(exc)
        if isinstance(exc, _requests.HTTPError) and exc.response is not None:
            try:    detail = exc.response.json()
            except Exception: detail = exc.response.text
        log.error("%s — %s", msg, detail)
        return HTTPException(status.HTTP_502_BAD_GATEWAY, f"{msg}: {detail}")

    # ── CREATE ───────────────────────────────────────────────────────────────

    async def create(self, payload: ScheduleCreate) -> JobSchedule:
        clash = await self.db.scalar(
            select(JobSchedule).where(
                JobSchedule.name == payload.name,
                JobSchedule.job_template_id == payload.job_template_id,
                JobSchedule.sync_status != SyncStatus.DELETED,
            )
        )
        if clash:
            raise HTTPException(
                status.HTTP_409_CONFLICT,
                f"Schedule '{payload.name}' already exists on JT {payload.job_template_id}",
            )

        rrule    = self._build_rrule(payload)
        freq_val = FreqType.ONCE if payload.once else payload.recurring.freq
        tz       = payload.once.timezone if payload.once else payload.recurring.timezone

        rec = JobSchedule(
            name=payload.name, description=payload.description,
            job_template_id=payload.job_template_id, job_template_name=payload.job_template_name,
            rrule=rrule, freq_type=freq_val, timezone=tz,
            enabled=payload.enabled, sync_status=SyncStatus.PENDING,
            created_by=payload.created_by, extra_data=payload.extra_data,
            limit=payload.limit, job_tags=payload.job_tags, skip_tags=payload.skip_tags,
        )
        self.db.add(rec)
        await self.db.flush()  # get UUID before AAP call

        try:
            resp = self.aap.create_schedule(payload.job_template_id, self._to_aap_payload(rec))
            self._stamp_aap(rec, resp)
        except Exception as exc:
            rec.sync_status = SyncStatus.FAILED
            raise self._aap_502(exc, "Schedule saved locally but AAP push failed")

        await self.db.flush()
        await self.db.refresh(rec)
        return rec

    # ── READ ─────────────────────────────────────────────────────────────────

    async def get(self, sid: uuid.UUID, refresh_from_aap: bool = False) -> JobSchedule:
        rec = await self._get_or_404(sid)
        if refresh_from_aap and rec.aap_schedule_id and rec.sync_status == SyncStatus.SYNCED:
            try:
                raw = self.aap.get_schedule(rec.aap_schedule_id).get("next_run")
                if raw:
                    rec.next_run = datetime.fromisoformat(raw.replace("Z", "+00:00"))
                await self.db.flush()
            except Exception as exc:
                log.warning("Could not refresh next_run from AAP: %s", exc)
        return rec

    # ── READ ALL ─────────────────────────────────────────────────────────────

    async def list_all(self, f: ScheduleFilter) -> tuple[list[JobSchedule], int]:
        q  = select(JobSchedule)
        cq = select(func.count()).select_from(JobSchedule)

        def _w(col, val):
            nonlocal q, cq
            q  = q.where(col == val)
            cq = cq.where(col == val)

        if f.job_template_id is not None: _w(JobSchedule.job_template_id, f.job_template_id)
        if f.freq_type        is not None: _w(JobSchedule.freq_type,       f.freq_type)
        if f.enabled          is not None: _w(JobSchedule.enabled,         f.enabled)
        if f.sync_status      is not None: _w(JobSchedule.sync_status,     f.sync_status)
        if f.created_by       is not None: _w(JobSchedule.created_by,      f.created_by)
        if f.name_contains:
            p  = f"%{f.name_contains.lower()}%"
            q  = q.where(func.lower(JobSchedule.name).like(p))
            cq = cq.where(func.lower(JobSchedule.name).like(p))

        total  = await self.db.scalar(cq) or 0
        offset = (f.page - 1) * f.page_size
        q      = q.order_by(JobSchedule.created_at.desc()).offset(offset).limit(f.page_size)
        rows   = (await self.db.execute(q)).scalars().all()
        return list(rows), total

    # ── UPDATE ───────────────────────────────────────────────────────────────

    async def update(self, sid: uuid.UUID, payload: ScheduleUpdate) -> JobSchedule:
        rec = await self._get_or_404(sid)
        if rec.sync_status == SyncStatus.DELETED:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Cannot update a deleted schedule")

        patch: dict = {}

        if payload.description is not None:
            rec.description = payload.description;         patch["description"] = payload.description
        if payload.enabled is not None:
            rec.enabled     = payload.enabled;             patch["enabled"] = payload.enabled
        if payload.extra_data is not None:
            rec.extra_data  = payload.extra_data;          patch["extra_data"] = payload.extra_data
        if payload.limit is not None:
            rec.limit       = payload.limit;               patch["limit"] = payload.limit
        if payload.job_tags is not None:
            rec.job_tags    = payload.job_tags;            patch["job_tags"] = payload.job_tags
        if payload.skip_tags is not None:
            rec.skip_tags   = payload.skip_tags;           patch["skip_tags"] = payload.skip_tags

        new_rrule = self._build_rrule(payload)
        if new_rrule:
            rec.rrule = new_rrule;                         patch["rrule"] = new_rrule
            if payload.once:
                rec.freq_type = FreqType.ONCE;  rec.timezone = payload.once.timezone
            elif payload.recurring:
                rec.freq_type = payload.recurring.freq; rec.timezone = payload.recurring.timezone

        if patch and rec.aap_schedule_id and rec.sync_status == SyncStatus.SYNCED:
            try:
                self._stamp_aap(rec, self.aap.update_schedule(rec.aap_schedule_id, patch))
            except Exception as exc:
                rec.sync_status = SyncStatus.FAILED
                raise self._aap_502(exc, "Local updated but AAP sync failed")

        await self.db.flush()
        await self.db.refresh(rec)
        return rec

    # ── DELETE ───────────────────────────────────────────────────────────────

    async def delete(self, sid: uuid.UUID) -> JobSchedule:
        rec = await self._get_or_404(sid)
        if rec.sync_status == SyncStatus.DELETED:
            raise HTTPException(status.HTTP_409_CONFLICT, "Schedule is already deleted")
        if rec.aap_schedule_id and rec.sync_status == SyncStatus.SYNCED:
            try:
                self.aap.delete_schedule(rec.aap_schedule_id)
            except Exception as exc:
                raise self._aap_502(exc, "AAP deletion failed — local record unchanged")
        rec.sync_status    = SyncStatus.DELETED
        rec.enabled        = False
        rec.last_synced_at = datetime.now(tz=timezone.utc)
        await self.db.flush()
        await self.db.refresh(rec)
        return rec

    # ── SYNC (retry pending/failed) ──────────────────────────────────────────

    async def sync(self, sid: uuid.UUID) -> JobSchedule:
        rec = await self._get_or_404(sid)
        if rec.sync_status == SyncStatus.DELETED:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Cannot sync a deleted schedule")
        if rec.sync_status == SyncStatus.SYNCED:
            raise HTTPException(status.HTTP_409_CONFLICT, "Already synced — use PATCH to modify it")
        try:
            if rec.aap_schedule_id:
                resp = self.aap.update_schedule(rec.aap_schedule_id, {"rrule": rec.rrule, "enabled": rec.enabled})
            else:
                resp = self.aap.create_schedule(rec.job_template_id, self._to_aap_payload(rec))
            self._stamp_aap(rec, resp)
        except Exception as exc:
            rec.sync_status = SyncStatus.FAILED
            raise self._aap_502(exc, "Sync attempt failed")
        await self.db.flush()
        await self.db.refresh(rec)
        return rec

"""
AAP Job Schedule router  —  /api/v1/schedules

Endpoints
─────────────────────────────────────────────────────────────────────────────
POST   /schedules                  Create a schedule and push to AAP
GET    /schedules                  List all schedules (filtered + paginated)
GET    /schedules/{id}             Get one schedule by UUID
PATCH  /schedules/{id}             Partially update a schedule
DELETE /schedules/{id}             Soft-delete (removes from AAP, keeps audit record)
POST   /schedules/{id}/sync        Retry a pending/failed schedule push to AAP
"""
from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.aap.client import AAPClient, get_aap_client
from app.db.database import get_db
from app.schemas.schedule import (
    APIResponse,
    FreqType,
    PaginationMeta,
    ScheduleCreate,
    ScheduleFilter,
    ScheduleResponse,
    ScheduleUpdate,
    SyncStatus,
)
from app.services.schedule_service import ScheduleService

router = APIRouter(prefix="/schedules", tags=["AAP Job Schedules"])


# ── dependency injection ──────────────────────────────────────────────────────

async def get_service(
    db:  AsyncSession = Depends(get_db),
    aap: AAPClient    = Depends(get_aap_client),
) -> ScheduleService:
    return ScheduleService(db=db, aap=aap)


Svc = Annotated[ScheduleService, Depends(get_service)]


# ── CREATE ────────────────────────────────────────────────────────────────────

@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
    response_model=APIResponse[ScheduleResponse],
    summary="Create a new AAP job schedule",
    responses={
        201: {"description": "Schedule created and pushed to AAP"},
        409: {"description": "A schedule with this name already exists on the job template"},
        422: {"description": "Validation error — check 'once' vs 'recurring', required fields"},
        502: {"description": "Schedule saved locally but AAP push failed — retry via /sync"},
    },
)
async def create_schedule(
    payload: ScheduleCreate,
    svc:     Svc,
) -> APIResponse[ScheduleResponse]:
    """
    Create a schedule on an **AAP Job Template** and register it in the platform.

    ### Timing — provide exactly one of:
    | Field | When to use |
    |---|---|
    | `once` | Run the job a single time at a specific datetime |
    | `recurring` | Repeat on a cron-like cadence (DAILY, WEEKLY, MONTHLY …) |

    ### Common `recurring.freq` values:
    | freq | interval example | Effect |
    |---|---|---|
    | `DAILY` | 1 | Every day |
    | `WEEKLY` | 1 + `byday:"MO,WE,FR"` | Mon, Wed, Fri |
    | `HOURLY` | 6 | Every 6 hours |
    | `MONTHLY` | 1 + `byday:"SA"` | Every Saturday |

    ### Playbook overrides (`extra_data`, `limit`, `job_tags`, `skip_tags`)
    These are passed directly to the Ansible playbook at runtime and
    override the defaults set on the Job Template.

    ### Sync behaviour
    The schedule is saved locally first (`sync_status=pending`), then pushed
    to AAP. If the AAP push fails the record stays with `sync_status=failed`
    — use **POST /schedules/{id}/sync** to retry without losing the request.
    """
    rec = await svc.create(payload)
    return APIResponse.ok(
        data=ScheduleResponse.model_validate(rec),
        message=f"Schedule '{rec.name}' created (sync_status={rec.sync_status})",
    )


# ── READ ALL ──────────────────────────────────────────────────────────────────

@router.get(
    "",
    response_model=APIResponse[list[ScheduleResponse]],
    summary="List all AAP job schedules",
    responses={200: {"description": "Paginated list of schedules"}},
)
async def list_schedules(
    svc:             Svc,
    job_template_id: int | None       = Query(None,  description="Filter by AAP job template ID"),
    freq_type:       FreqType | None  = Query(None,  description="Filter by schedule frequency"),
    enabled:         bool | None      = Query(None,  description="true = active schedules only"),
    sync_status:     SyncStatus | None = Query(None, description="pending | synced | failed | deleted"),
    created_by:      str | None       = Query(None,  description="Filter by creator username"),
    name_contains:   str | None       = Query(None,  description="Case-insensitive name substring"),
    page:            int              = Query(1,   ge=1),
    page_size:       int              = Query(20,  ge=1, le=100),
) -> APIResponse[list[ScheduleResponse]]:
    """
    List all platform schedules with optional filters.

    Results are ordered **newest first** (`created_at DESC`).

    ### Useful filter combinations:
    - `?sync_status=failed` — find schedules that need re-syncing after an AAP outage
    - `?enabled=true&job_template_id=42` — all active schedules for a specific JT
    - `?created_by=pradeep` — schedules owned by a specific person
    - `?freq_type=once&sync_status=synced` — completed one-time runs
    - `?name_contains=compliance` — find schedules by partial name match
    """
    f = ScheduleFilter(
        job_template_id=job_template_id,
        freq_type=freq_type,
        enabled=enabled,
        sync_status=sync_status,
        created_by=created_by,
        name_contains=name_contains,
        page=page,
        page_size=page_size,
    )
    records, total = await svc.list_all(f)
    return APIResponse.ok(
        data=[ScheduleResponse.model_validate(r) for r in records],
        meta=PaginationMeta.build(total=total, page=page, page_size=page_size),
    )


# ── READ ONE ──────────────────────────────────────────────────────────────────

@router.get(
    "/{schedule_id}",
    response_model=APIResponse[ScheduleResponse],
    summary="Get a single schedule by UUID",
    responses={
        200: {"description": "Schedule found"},
        404: {"description": "Schedule not found"},
    },
)
async def get_schedule(
    schedule_id: uuid.UUID,
    svc:         Svc,
    refresh:     bool = Query(
        False,
        description=(
            "If true, fetch the latest next_run from AAP before returning. "
            "Adds one AAP API call but ensures accuracy."
        ),
    ),
) -> APIResponse[ScheduleResponse]:
    """
    Fetch a single schedule by its platform UUID.

    Add `?refresh=true` to pull a live `next_run` value from AAP —
    useful when displaying an upcoming execution time in a UI.
    """
    rec = await svc.get(schedule_id, refresh_from_aap=refresh)
    return APIResponse.ok(data=ScheduleResponse.model_validate(rec))


# ── UPDATE ────────────────────────────────────────────────────────────────────

@router.patch(
    "/{schedule_id}",
    response_model=APIResponse[ScheduleResponse],
    summary="Partially update a schedule",
    responses={
        200: {"description": "Schedule updated"},
        404: {"description": "Schedule not found"},
        422: {"description": "Cannot update a deleted schedule, or validation error"},
        502: {"description": "Local record updated but AAP patch failed"},
    },
)
async def update_schedule(
    schedule_id: uuid.UUID,
    payload:     ScheduleUpdate,
    svc:         Svc,
) -> APIResponse[ScheduleResponse]:
    """
    Partially update a schedule — **PATCH semantics**.

    Only the fields you include in the request body are changed.
    Fields you omit are left exactly as they are.

    ### What can be updated:
    | Field | Effect |
    |---|---|
    | `enabled` | Pause (`false`) or resume (`true`) without deleting |
    | `once` / `recurring` | Replaces the entire timing definition and rebuilds the rrule |
    | `extra_data` | Replaces all playbook extra vars |
    | `limit` | Changes the host limit pattern |
    | `job_tags` / `skip_tags` | Changes which Ansible tags run |
    | `description` | Updates the human-readable note |

    Changes are patched in AAP immediately if the schedule is `synced`.
    If already `failed`, update the local record and use **/sync** to push.

    Cannot update a `deleted` schedule.
    """
    rec = await svc.update(schedule_id, payload)
    return APIResponse.ok(
        data=ScheduleResponse.model_validate(rec),
        message=f"Schedule '{rec.name}' updated",
    )


# ── DELETE ────────────────────────────────────────────────────────────────────

@router.delete(
    "/{schedule_id}",
    response_model=APIResponse[ScheduleResponse],
    summary="Soft-delete a schedule",
    responses={
        200: {"description": "Schedule removed from AAP; local audit record retained"},
        404: {"description": "Schedule not found"},
        409: {"description": "Already deleted"},
        502: {"description": "AAP deletion failed — local record unchanged"},
    },
)
async def delete_schedule(
    schedule_id: uuid.UUID,
    svc:         Svc,
) -> APIResponse[ScheduleResponse]:
    """
    **Soft-delete** a schedule.

    - Calls the AAP API to remove the schedule so it **stops firing**
    - Sets local `sync_status = deleted` and `enabled = false`
    - **Keeps the local record** for audit trail, charge-back, and reporting

    This is intentionally non-destructive at the DB level.
    If you need to permanently erase the record, call your DBA directly.

    Returns 409 if the schedule is already deleted.
    Returns 502 if AAP deletion fails — the local record is left unchanged
    so you can investigate and retry.
    """
    rec = await svc.delete(schedule_id)
    return APIResponse.ok(
        data=ScheduleResponse.model_validate(rec),
        message=f"Schedule '{rec.name}' removed from AAP and marked deleted",
    )


# ── SYNC ──────────────────────────────────────────────────────────────────────

@router.post(
    "/{schedule_id}/sync",
    response_model=APIResponse[ScheduleResponse],
    summary="Re-push a pending or failed schedule to AAP",
    responses={
        200: {"description": "Successfully synced to AAP"},
        404: {"description": "Schedule not found"},
        409: {"description": "Already synced — use PATCH to update it"},
        422: {"description": "Cannot sync a deleted schedule"},
        502: {"description": "Sync attempt failed — check AAP connectivity"},
    },
)
async def sync_schedule(
    schedule_id: uuid.UUID,
    svc:         Svc,
) -> APIResponse[ScheduleResponse]:
    """
    Retry the AAP push for a schedule in **`pending`** or **`failed`** state.

    ### When to use this:
    - After an AAP outage — schedules that failed to sync are preserved locally with
      `sync_status=failed`. Hit this endpoint once AAP is back up.
    - After a credential rotation that caused a temporary 401 from AAP.
    - When `POST /schedules` returned a 502 but the record was saved locally.

    Returns 409 if the schedule is already `synced` — use **PATCH** to modify a synced schedule.
    Returns 422 for `deleted` schedules.
    """
    rec = await svc.sync(schedule_id)
    return APIResponse.ok(
        data=ScheduleResponse.model_validate(rec),
        message=f"Schedule '{rec.name}' synced (AAP id={rec.aap_schedule_id})",
    )

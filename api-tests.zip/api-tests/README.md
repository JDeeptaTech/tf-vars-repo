# VM Platform API Test Suite

End-to-end API tests for the VM self-service platform built with **pytest + httpx**.
Supports parallel execution, multi-environment payloads, VM profile matrices, and
full auth/RBAC coverage.

---

## Quick start

```bash
pip install -r requirements.txt

pytest \
  --api-url=https://vm-api.dev.internal \
  --token=<your-bearer-token> \
  --env=dev \
  --matrix=smoke
```

---

## Project structure

```
api-tests/
├── conftest.py                  # CLI args, shared fixtures, payload/profile loaders
├── pytest.ini                   # markers, default addopts
├── Jenkinsfile                  # Multibranch pipeline (auto + on-demand)
├── requirements.txt
│
├── payloads/                    # Three-layer payload resolution
│   ├── base/                    # Canonical defaults
│   ├── dev/                     # Dev-specific overrides (sparse)
│   ├── uat/
│   └── prod/
│
├── profiles/                    # VM flavour definitions
│   ├── base/profiles.yaml       # All profiles + named matrices
│   ├── dev/profiles.yaml        # Dev overrides (e.g. smaller SAP, different networks)
│   └── prod/profiles.yaml       # Prod network overrides
│
├── auth/
│   ├── credentials.yaml         # Identity → Jenkins credential ID mapping
│   └── permissions_matrix.yaml  # Role × operation → expected HTTP status
│
└── tests/
    ├── test_vm_create.py        # Creation tests — parametrized by profile matrix
    ├── test_day2_ops.py         # Day-2 ops — cross-product of profiles × operations
    └── auth/
        ├── test_token_validation.py   # No token / malformed / expired / wrong scheme
        ├── test_rbac.py               # Auto-expanded from permissions_matrix.yaml
        ├── test_token_lifecycle.py    # Introspection / expiry / rate limiting
        └── test_audit.py             # Denied + allowed ops appear in audit log
```

---

## CLI options

| Option | Default | Description |
|---|---|---|
| `--api-url` | *(required)* | Base API URL |
| `--token` | *(required)* | Bearer token for primary (admin) client |
| `--env` | `dev` | Target environment: `dev` / `uat` / `prod` |
| `--matrix` | `smoke` | VM profile matrix: `smoke` / `linux_all` / `windows_all` / `full` |
| `--payload` | *(none)* | Path to a JSON file applied as top-level payload override |

---

## Running examples

```bash
# Smoke — rhel9-small + win2022-std (fast, good for PRs)
pytest --api-url=... --token=... --env=dev --matrix=smoke

# All Linux profiles in parallel
pytest --api-url=... --token=... --env=uat --matrix=linux_all -n 4

# Full matrix on prod — limited workers
pytest --api-url=... --token=... --env=prod --matrix=full -n 2 -m regression

# Auth tests only
pytest tests/auth/ --api-url=... --token=...

# RBAC matrix for a specific role
pytest tests/auth/test_rbac.py -k "vm_viewer" --api-url=... --token=...

# Day-2 resize only
pytest tests/test_day2_ops.py -k "resize" --api-url=... --token=...

# Dry run — collect tests without executing
pytest --collect-only --api-url=... --token=... --matrix=full

# With payload override file
pytest --api-url=... --token=... --payload=./my_override.json
```

---

## VM profiles and matrices

Profiles are defined in `profiles/base/profiles.yaml`.
Matrices are named groups of profiles:

| Matrix | Profiles included |
|---|---|
| `smoke` | rhel9-small, win2022-std |
| `linux_all` | rhel9-small, rhel9-large, ubuntu-22, sap-hana |
| `windows_all` | win2022-std, win2019-dc, win2022-cluster-2node, win2022-cluster-3node |
| `full` | All of the above |

**Adding a new flavour:** add an entry to `profiles/base/profiles.yaml` and
include its key in the relevant matrix groups. No code changes needed.

---

## Payload resolution order

```
payloads/base/<name>.json          ← always loaded
         ↓ deep merge
payloads/<env>/<name>.json         ← env layer (skipped if file absent)
         ↓ deep merge
--payload <file>.json              ← CLI ad-hoc override (optional)
         ↓ deep merge
extra={...} in get_payload(...)    ← per-test inline override (optional)
```

---

## Auth test identities

Tokens are resolved from environment variables:

| Identity | Env var |
|---|---|
| platform_admin | `TEST_TOKEN_TEST_TOKEN_PLATFORM_ADMIN` |
| vm_operator | `TEST_TOKEN_TEST_TOKEN_VM_OPERATOR` |
| vm_viewer | `TEST_TOKEN_TEST_TOKEN_VM_VIEWER` |
| sap_team | `TEST_TOKEN_TEST_TOKEN_SAP_TEAM` |
| no_permissions | `TEST_TOKEN_TEST_TOKEN_NO_PERMISSIONS` |
| expired | `TEST_TOKEN_TEST_TOKEN_EXPIRED` |

Tests for identities without a token are **automatically skipped** (not failed).

---

## Jenkins Multibranch Pipeline

Branch → environment mapping:

| Branch pattern | Environment | Matrix default |
|---|---|---|
| `main` / `master` | prod | smoke |
| `uat` | uat | smoke |
| `dev/*` / `feature/*` / `fix/*` | dev | smoke |
| PR | dev | smoke (no `prod_only` tests) |

**On-demand run** — click *Build with Parameters* on any branch in Jenkins UI
and override environment, matrix, test filter, worker count, and payload.

---

## Pytest markers

| Marker | Usage |
|---|---|
| `smoke` | Fast subset — every PR |
| `regression` | Full suite — uat/prod branches |
| `prod_only` | Skipped on PRs and dev |
| `linux_only` | Linux profile tests |
| `windows_only` | Windows profile tests |
| `cluster` | Multi-node cluster tests |
| `auth` | Authentication / authorisation |
| `audit` | Audit trail (requires audit log endpoint) |

```bash
# Run smoke tests only
pytest -m smoke --api-url=... --token=...

# Skip audit tests (e.g. endpoint not available in dev)
pytest tests/auth/ -m "not audit" --api-url=... --token=...
```

---

## Parallel execution (pytest-xdist)

```bash
# Auto — one worker per CPU core
pytest -n auto --api-url=... --token=...

# Fixed — good for rate-limited APIs
pytest -n 4 --api-url=... --token=...

# Keep lifecycle tests on same worker
pytest -n 4 --dist=loadgroup --api-url=... --token=...
```

The `unique_name` fixture (`test-<8-char-hex>`) ensures no resource name
collisions between parallel workers.

---

## Adding a new test

1. Add test function to the appropriate file in `tests/`
2. Use `vm_profile`, `unique_name`, `poll_request`, `get_payload` fixtures
3. Add a pytest marker if needed
4. No changes to `conftest.py` required for standard cases

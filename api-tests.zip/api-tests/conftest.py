import os
import time
import uuid
import json
import yaml
import pytest
import httpx
from pathlib import Path

PAYLOADS_DIR = Path(__file__).parent / "payloads"
PROFILES_DIR = Path(__file__).parent / "profiles"
AUTH_DIR     = Path(__file__).parent / "auth"


# ── CLI arguments ─────────────────────────────────────────────────────────────

def pytest_addoption(parser):
    parser.addoption("--api-url",  required=True,  help="Base API URL")
    parser.addoption("--token",    required=True,  help="Bearer token (platform_admin)")
    parser.addoption("--env",      default="dev",
                     choices=["dev", "uat", "prod"],
                     help="Target environment")
    parser.addoption("--payload",  default=None,   help="Path to ad-hoc JSON override file")
    parser.addoption("--matrix",   default="smoke",
                     choices=["smoke", "linux_all", "windows_all", "full"],
                     help="Named test matrix from profiles.yaml")


# ── Core fixtures ─────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def env(request) -> str:
    return request.config.getoption("--env")


@pytest.fixture(scope="session")
def client(request) -> httpx.Client:
    """Primary authenticated client (platform_admin). One per xdist worker."""
    base_url = request.config.getoption("--api-url").rstrip("/")
    token    = request.config.getoption("--token")
    with httpx.Client(
        base_url=base_url,
        headers={"Authorization": f"Bearer {token}"},
        timeout=30,
    ) as c:
        yield c


@pytest.fixture
def unique_name() -> str:
    """Short unique resource name — prevents worker collisions in parallel runs."""
    return f"test-{uuid.uuid4().hex[:8]}"


# ── Payload loader ────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def cli_override(request) -> dict:
    path = request.config.getoption("--payload")
    return json.loads(Path(path).read_text()) if path else {}


@pytest.fixture(scope="session")
def get_payload(env, cli_override):
    """
    Three-layer payload resolver:
      1. payloads/base/<name>.json
      2. payloads/<env>/<name>.json   (sparse overrides)
      3. --payload CLI file           (ad-hoc override)
      4. extra= dict per call         (inline override)
    """
    def _load(name: str, extra: dict | None = None) -> dict:
        result = {}

        base_file = PAYLOADS_DIR / "base" / f"{name}.json"
        if base_file.exists():
            result.update(json.loads(base_file.read_text()))

        env_file = PAYLOADS_DIR / env / f"{name}.json"
        if env_file.exists():
            result = _deep_merge(result, json.loads(env_file.read_text()))

        if cli_override:
            result = _deep_merge(result, cli_override)

        if extra:
            result = _deep_merge(result, extra)

        return result

    return _load


# ── Profile registry ──────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def profile_registry(env) -> dict:
    """
    Loads base profiles deep-merged with env overrides.
    Stored on config for pytest_generate_tests access.
    """
    def _load_yaml(path: Path) -> dict:
        return yaml.safe_load(path.read_text()) if path.exists() else {}

    base    = _load_yaml(PROFILES_DIR / "base" / "profiles.yaml")
    overlay = _load_yaml(PROFILES_DIR / env  / "profiles.yaml")

    resolved = {
        "profiles": dict(base.get("profiles", {})),
        "matrices": dict(base.get("matrices", {})),
    }

    for name, overrides in overlay.get("profiles", {}).items():
        if name in resolved["profiles"]:
            resolved["profiles"][name] = _deep_merge(
                resolved["profiles"][name], overrides
            )

    return resolved


def get_matrix_params(profile_registry: dict, matrix_name: str) -> list:
    """Returns pytest.param list for a named matrix group."""
    names    = profile_registry["matrices"].get(matrix_name, [])
    profiles = profile_registry["profiles"]
    return [
        pytest.param(profiles[n], id=n)
        for n in names
        if n in profiles
    ]


# ── Async polling ─────────────────────────────────────────────────────────────

POLL_INTERVAL = 5    # seconds between status checks
MAX_WAIT      = 120  # seconds before giving up


@pytest.fixture
def poll_request(client):
    """Polls /api/v1/requests/<id> until terminal state or timeout."""
    def _poll(request_id: str) -> dict:
        elapsed = 0
        while elapsed < MAX_WAIT:
            r = client.get(f"/api/v1/requests/{request_id}")
            r.raise_for_status()
            data = r.json()["data"]
            if data["status"] in ("completed", "failed", "error"):
                return data
            time.sleep(POLL_INTERVAL)
            elapsed += POLL_INTERVAL
        pytest.fail(f"Request {request_id} did not complete within {MAX_WAIT}s")

    return _poll


# ── Multi-identity client factory (auth tests) ────────────────────────────────

@pytest.fixture(scope="session")
def credentials() -> dict:
    return yaml.safe_load((AUTH_DIR / "credentials.yaml").read_text())["identities"]


@pytest.fixture(scope="session")
def permissions_matrix() -> dict:
    return yaml.safe_load(
        (AUTH_DIR / "permissions_matrix.yaml").read_text()
    )["permissions"]


@pytest.fixture(scope="session")
def client_factory(request, credentials):
    """
    Returns a callable that builds an httpx.Client for any test identity.
    Token resolution:
      1. Env var  TEST_TOKEN_<CREDENTIAL_ID_UPPER>
      2. 'literal' key in credentials.yaml (malformed/static tokens)
    Skips the test automatically if no token is available.
    """
    api_url = request.config.getoption("--api-url").rstrip("/")
    clients: dict[str, httpx.Client] = {}

    def _get(identity_name: str) -> httpx.Client:
        if identity_name in clients:
            return clients[identity_name]

        identity = credentials[identity_name]

        if "literal" in identity:
            token = identity["literal"]
        else:
            cred_id = identity["credential_id"].upper().replace("-", "_")
            env_var = f"TEST_TOKEN_{cred_id}"
            token   = os.environ.get(env_var, "")
            if not token:
                pytest.skip(f"Token not available — set env var {env_var}")

        auth_header = token if token.startswith("Bearer") else f"Bearer {token}"
        c = httpx.Client(
            base_url=api_url,
            headers={"Authorization": auth_header},
            timeout=30,
        )
        clients[identity_name] = c
        return c

    yield _get

    for c in clients.values():
        c.close()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base. Override wins on conflicts."""
    result = base.copy()
    for key, val in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = _deep_merge(result[key], val)
        else:
            result[key] = val
    return result

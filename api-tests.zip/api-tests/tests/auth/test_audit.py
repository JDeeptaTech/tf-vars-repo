"""
Audit trail tests — denied and allowed operations must appear in the audit log.

These tests require:
  - An audit log endpoint accessible to platform_admin
  - X-Request-ID header returned on every response
  - platform_admin token available via client_factory
"""
import pytest


@pytest.mark.auth
@pytest.mark.audit
class TestAuditTrail:

    def test_denied_request_appears_in_audit_log(self, client_factory, unique_name):
        """A 403 denial must create an audit entry with outcome=denied."""
        viewer = client_factory("vm_viewer")
        admin  = client_factory("platform_admin")

        # Trigger a denied write
        r = viewer.post("/api/v1/vms", json={
            "name": unique_name, "cpu": 2,
            "memory_gb": 4, "os_image": "rhel-9",
        })
        assert r.status_code == 403
        request_id = r.headers.get("X-Request-ID")
        assert request_id, "X-Request-ID header missing from denied response"

        # Check audit log
        audit = admin.get(f"/api/v1/audit?request_id={request_id}")
        assert audit.status_code == 200
        entry = audit.json()["data"]

        assert entry["outcome"]  == "denied"
        assert entry["reason"]   == "insufficient_permissions"
        assert entry["identity"] is not None
        assert entry["resource"] is not None

    def test_successful_request_appears_in_audit_log(self, client_factory,
                                                      unique_name, poll_request):
        """A successful VM creation must create an audit entry with outcome=allowed."""
        operator = client_factory("vm_operator")
        admin    = client_factory("platform_admin")

        r = operator.post("/api/v1/vms", json={
            "name": unique_name, "cpu": 2,
            "memory_gb": 4, "os_image": "rhel-9",
            "network": "default-net",
        })
        assert r.status_code == 202
        request_id = r.headers.get("X-Request-ID")
        poll_request(r.json()["data"]["request_id"])

        audit = admin.get(f"/api/v1/audit?request_id={request_id}")
        assert audit.status_code == 200
        entry = audit.json()["data"]

        assert entry["outcome"]   == "allowed"
        assert entry["identity"]  == "vm_operator"
        assert entry["resource"]  == f"vm/{unique_name}"
        assert entry["action"]    == "vm_create"

    def test_audit_log_not_accessible_to_viewer(self, client_factory):
        """vm_viewer must not be able to read the audit log."""
        c = client_factory("vm_viewer")
        r = c.get("/api/v1/audit")
        assert r.status_code == 403

    def test_audit_log_not_accessible_to_operator(self, client_factory):
        """vm_operator must not be able to read the audit log."""
        c = client_factory("vm_operator")
        r = c.get("/api/v1/audit")
        assert r.status_code == 403

    def test_audit_entries_contain_required_fields(self, client_factory):
        """Audit log entries must include all required compliance fields."""
        admin = client_factory("platform_admin")
        r = admin.get("/api/v1/audit?limit=10")
        assert r.status_code == 200

        entries = r.json()["data"]["items"]
        assert entries, "Audit log is empty"

        required_fields = {
            "request_id", "timestamp", "identity",
            "action", "resource", "outcome", "source_ip",
        }
        for entry in entries:
            missing = required_fields - set(entry.keys())
            assert not missing, (
                f"Audit entry missing required fields: {missing}\n"
                f"Entry: {entry}"
            )

    def test_audit_log_is_immutable(self, client_factory):
        """Audit log entries must not be deletable — even by platform_admin."""
        admin = client_factory("platform_admin")

        # Get latest entry ID
        r = admin.get("/api/v1/audit?limit=1")
        assert r.status_code == 200
        entries = r.json()["data"]["items"]
        if not entries:
            pytest.skip("No audit entries available")

        entry_id = entries[0]["request_id"]

        # Attempt to delete — must be rejected
        r = admin.delete(f"/api/v1/audit/{entry_id}")
        assert r.status_code in (403, 405), (
            f"Audit entries should not be deletable, got {r.status_code}"
        )

    def test_unauthenticated_request_is_audited(self, request, client_factory):
        """Requests with no token must still appear in the audit log."""
        import httpx
        api_url = request.config.getoption("--api-url")
        admin   = client_factory("platform_admin")

        with httpx.Client(base_url=api_url, timeout=10) as bare:
            r = bare.get("/api/v1/vms")
        assert r.status_code == 401
        request_id = r.headers.get("X-Request-ID")
        if not request_id:
            pytest.skip("No X-Request-ID on unauthenticated response")

        audit = admin.get(f"/api/v1/audit?request_id={request_id}")
        assert audit.status_code == 200
        entry = audit.json()["data"]
        assert entry["outcome"] == "denied"
        assert entry["reason"]  in ("no_token", "unauthenticated")

"""
RBAC permission matrix tests — auto-expanded from permissions_matrix.yaml.

Every role × operation combination becomes an individual test:
  test_rbac_permission[platform_admin-vm_create]   PASSED
  test_rbac_permission[vm_viewer-vm_create]        PASSED  (asserts 403)
  ... 40+ combinations total

Add a new role or operation → update permissions_matrix.yaml only.
No code changes needed.
"""
import pytest
import yaml
from pathlib import Path

AUTH_DIR = Path(__file__).parent.parent.parent / "auth"

# ── Map operation names → (HTTP method, URL template, minimal body) ───────────
OPERATION_MAP = {
    "vm_list":            ("GET",    "/api/v1/vms",                          None),
    "vm_create":          ("POST",   "/api/v1/vms",                          None),   # body built per-test
    "vm_delete":          ("DELETE", "/api/v1/vms/{name}",                   None),
    "vm_resize":          ("POST",   "/api/v1/vms/{name}/resize",            {"cpu": 4}),
    "cluster_create":     ("POST",   "/api/v1/clusters",                     None),
    "cluster_failover":   ("POST",   "/api/v1/clusters/{name}/failover",     {}),
    "admin_config_read":  ("GET",    "/api/v1/admin/config",                 None),
    "admin_config_write": ("PUT",    "/api/v1/admin/config",                 {"key": "test"}),
}


def _build_rbac_params() -> list:
    """Read permissions_matrix.yaml and expand to pytest.param list."""
    matrix = yaml.safe_load(
        (AUTH_DIR / "permissions_matrix.yaml").read_text()
    )["permissions"]

    params = []
    for role, operations in matrix.items():
        for op, expectation in operations.items():
            params.append(pytest.param(
                role,
                op,
                expectation["expected"],
                expectation["status"],
                id=f"{role}-{op}",
            ))
    return params


@pytest.mark.auth
@pytest.mark.parametrize("role,operation,should_succeed,expected_status",
                         _build_rbac_params())
def test_rbac_permission(client_factory, role, operation,
                         should_succeed, expected_status, unique_name):
    """
    Asserts that each role receives exactly the expected HTTP status
    for each operation — success (2xx) or denial (401/403).
    """
    method, url_template, body = OPERATION_MAP[operation]
    url = url_template.format(name=unique_name)

    # Build minimal create body for write ops
    if operation == "vm_create":
        body = {
            "name": unique_name,
            "cpu": 2,
            "memory_gb": 4,
            "os_image": "rhel-9",
            "network": "default-net",
        }
    if operation == "cluster_create":
        body = {"name": unique_name, "node_count": 2}

    c = client_factory(role)
    r = c.request(method, url, json=body)

    assert r.status_code == expected_status, (
        f"Role '{role}' on '{operation}': "
        f"expected HTTP {expected_status}, got {r.status_code}.\n"
        f"Body: {r.text}"
    )


@pytest.mark.auth
def test_cross_namespace_isolation(client_factory):
    """SAP team must not see VMs in the platform namespace."""
    c = client_factory("sap_team")

    r = c.get("/api/v1/namespaces/platform/vms")
    assert r.status_code == 403, (
        f"SAP team should be denied platform namespace, got {r.status_code}"
    )

    # Their own namespace should work
    r = c.get("/api/v1/namespaces/sap/vms")
    assert r.status_code == 200


@pytest.mark.auth
def test_operator_cannot_access_admin_endpoints(client_factory):
    """vm_operator must be denied all /admin/* endpoints."""
    c = client_factory("vm_operator")
    admin_endpoints = [
        "/api/v1/admin/config",
        "/api/v1/admin/users",
        "/api/v1/admin/audit",
    ]
    for ep in admin_endpoints:
        r = c.get(ep)
        assert r.status_code in (403, 404), (
            f"vm_operator should not access {ep}, got {r.status_code}"
        )


@pytest.mark.auth
def test_viewer_gets_consistent_403_on_all_writes(client_factory, unique_name):
    """vm_viewer must be denied every mutating method."""
    c = client_factory("vm_viewer")
    write_ops = [
        ("POST",   "/api/v1/vms",                         {"name": unique_name, "cpu": 2}),
        ("DELETE", f"/api/v1/vms/{unique_name}",          None),
        ("POST",   f"/api/v1/vms/{unique_name}/resize",   {"cpu": 4}),
        ("POST",   f"/api/v1/vms/{unique_name}/snapshot", {"name": "snap"}),
    ]
    for method, url, body in write_ops:
        r = c.request(method, url, json=body)
        assert r.status_code == 403, (
            f"vm_viewer should be denied {method} {url}, got {r.status_code}"
        )

"""
Token lifecycle tests — introspection, expiry reflection, rate limiting.
"""
import httpx
import pytest


@pytest.mark.auth
class TestTokenLifecycle:

    def test_token_introspection_returns_claims(self, client_factory):
        """Valid token introspection returns active=True with expected claims."""
        c = client_factory("vm_operator")
        r = c.get("/api/v1/auth/introspect")
        assert r.status_code == 200
        body = r.json()["data"]
        assert body["active"] is True
        assert "exp"   in body, "Missing 'exp' claim"
        assert "roles" in body, "Missing 'roles' claim"
        assert "vm_operator" in body["roles"]

    def test_expired_token_shows_inactive(self, client_factory):
        """Expired token introspection returns active=False or 401."""
        c = client_factory("expired")
        r = c.get("/api/v1/auth/introspect")
        # APIs may return 200 + active=false, or just 401 — both acceptable
        if r.status_code == 200:
            assert r.json()["data"]["active"] is False
        else:
            assert r.status_code == 401

    def test_admin_token_has_elevated_roles(self, client_factory):
        """platform_admin token must declare admin-level roles."""
        c = client_factory("platform_admin")
        r = c.get("/api/v1/auth/introspect")
        assert r.status_code == 200
        roles = r.json()["data"]["roles"]
        assert any("admin" in role.lower() for role in roles), (
            f"No admin role found in: {roles}"
        )

    def test_viewer_token_has_readonly_scope(self, client_factory):
        """vm_viewer token must not have any write scopes."""
        c = client_factory("vm_viewer")
        r = c.get("/api/v1/auth/introspect")
        assert r.status_code == 200
        body = r.json()["data"]
        scopes = body.get("scopes", [])
        write_scopes = [s for s in scopes if "write" in s or "delete" in s]
        assert not write_scopes, (
            f"vm_viewer should have no write scopes, found: {write_scopes}"
        )

    def test_rate_limiting_on_repeated_bad_tokens(self, request):
        """Repeated invalid auth attempts must eventually trigger 429."""
        api_url = request.config.getoption("--api-url")
        with httpx.Client(
            base_url=api_url,
            headers={"Authorization": "Bearer bad.token.value"},
            timeout=10,
        ) as c:
            responses = [c.get("/api/v1/vms") for _ in range(20)]

        status_codes = {r.status_code for r in responses}
        assert 429 in status_codes, (
            f"Rate limiting not triggered after 20 bad requests. "
            f"Status codes seen: {status_codes}"
        )

    def test_token_identity_consistent_across_endpoints(self, client_factory):
        """Same token must return the same identity on every endpoint that echoes it."""
        c = client_factory("vm_operator")
        endpoints = [
            "/api/v1/auth/introspect",
            "/api/v1/auth/whoami",
        ]
        identities = set()
        for ep in endpoints:
            r = c.get(ep)
            if r.status_code == 200:
                body = r.json().get("data", {})
                identity = body.get("sub") or body.get("identity") or body.get("username")
                if identity:
                    identities.add(identity)

        assert len(identities) <= 1, (
            f"Inconsistent identity returned across endpoints: {identities}"
        )

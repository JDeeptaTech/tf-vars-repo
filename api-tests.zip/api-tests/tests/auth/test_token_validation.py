"""
Token validation tests — no token, malformed, expired, wrong scheme.
"""
import httpx
import pytest


@pytest.mark.auth
class TestTokenValidation:

    def test_no_auth_header_returns_401(self, request):
        """Request with no Authorization header must return 401."""
        api_url = request.config.getoption("--api-url")
        with httpx.Client(base_url=api_url, timeout=10) as bare:
            r = bare.get("/api/v1/vms")
        assert r.status_code == 401
        assert "WWW-Authenticate" in r.headers

    def test_malformed_token_returns_401(self, client_factory):
        """Structurally invalid JWT must return 401 with INVALID_TOKEN code."""
        c = client_factory("malformed")
        r = c.get("/api/v1/vms")
        assert r.status_code == 401
        body = r.json()
        assert body["error"]["code"] == "INVALID_TOKEN"

    def test_expired_token_returns_401(self, client_factory):
        """Valid JWT structure but past expiry must return 401."""
        c = client_factory("expired")
        r = c.get("/api/v1/vms")
        assert r.status_code == 401
        body = r.json()
        assert body["error"]["code"] in ("TOKEN_EXPIRED", "INVALID_TOKEN")

    def test_wrong_scheme_returns_401(self, request):
        """Basic auth scheme instead of Bearer must be rejected."""
        api_url = request.config.getoption("--api-url")
        with httpx.Client(
            base_url=api_url,
            headers={"Authorization": "Basic dXNlcjpwYXNz"},
            timeout=10,
        ) as c:
            r = c.get("/api/v1/vms")
        assert r.status_code == 401

    def test_empty_bearer_token_returns_401(self, request):
        """'Bearer ' with no token value must be rejected."""
        api_url = request.config.getoption("--api-url")
        with httpx.Client(
            base_url=api_url,
            headers={"Authorization": "Bearer "},
            timeout=10,
        ) as c:
            r = c.get("/api/v1/vms")
        assert r.status_code == 401

    def test_valid_token_viewer_returns_200(self, client_factory):
        """Sanity check — a valid viewer token can list VMs."""
        c = client_factory("vm_viewer")
        r = c.get("/api/v1/vms")
        assert r.status_code == 200

    def test_no_permissions_token_returns_403(self, client_factory):
        """Authenticated but zero RBAC — list must return 403."""
        c = client_factory("no_permissions")
        r = c.get("/api/v1/vms")
        assert r.status_code == 403

"""
Day-2 operations tests — cross-product of profiles × operations.

The parametrize decorators expand automatically:
  2 profiles × 3 ops = 6 tests for test_day2_all_profiles
  linux profiles × linux ops = N tests for test_day2_linux_only
  cluster ops run separately

Run examples:
  pytest tests/test_day2_ops.py --api-url=... --token=... --env=dev
  pytest tests/test_day2_ops.py -k "resize" --api-url=...
  pytest tests/test_day2_ops.py -m cluster --api-url=...
"""
import pytest


# ── Operation definitions ─────────────────────────────────────────────────────

ALL_PROFILE_OPS = [
    pytest.param("power_off",  {"action": "stop"},            id="power_off"),
    pytest.param("power_on",   {"action": "start"},           id="power_on"),
    pytest.param("snapshot",   {"name": "auto-test-snap"},    id="snapshot"),
]

LINUX_OPS = [
    pytest.param("resize",      {"cpu": 4, "memory_gb": 8},  id="resize_cpu_mem"),
    pytest.param("disk_expand", {"disk_gb": 80},              id="disk_expand"),
    pytest.param("migrate",     {"target_cluster": "cl-02"},  id="migrate"),
]

CLUSTER_OPS = [
    pytest.param("failover",  {"target_node": 1},             id="failover"),
    pytest.param("add_node",  {"node_count": 1},              id="add_node"),
    pytest.param("remove_node", {"node_index": 2},            id="remove_node"),
]

WINDOWS_OPS = [
    pytest.param("patch",  {"patch_group": "monthly"},        id="patch_monthly"),
    pytest.param("reboot", {"reason": "scheduled"},           id="reboot"),
]


# ── Profile sets ──────────────────────────────────────────────────────────────

MIXED_PROFILES = [
    pytest.param(
        {"os_family": "linux",   "os_image": "rhel-9",
         "cpu": 2, "memory_gb": 4, "disk_gb": 50, "network": "default-net"},
        id="rhel9"
    ),
    pytest.param(
        {"os_family": "windows", "os_image": "windows-server-2022-std",
         "cpu": 4, "memory_gb": 16, "disk_gb": 100, "network": "default-net"},
        id="win2022-std"
    ),
]

LINUX_PROFILES = [
    pytest.param(
        {"os_family": "linux", "os_image": "rhel-9",
         "cpu": 2, "memory_gb": 4, "disk_gb": 50, "network": "default-net"},
        id="rhel9"
    ),
    pytest.param(
        {"os_family": "linux", "os_image": "ubuntu-22.04",
         "cpu": 2, "memory_gb": 8, "disk_gb": 50, "network": "default-net"},
        id="ubuntu22"
    ),
]

CLUSTER_PROFILES = [
    pytest.param(
        {"os_family": "windows", "os_image": "windows-server-2022-dc",
         "cpu": 8, "memory_gb": 32, "disk_gb": 200,
         "network": "cluster-net", "node_count": 2, "cluster": True},
        id="win2022-2node"
    ),
    pytest.param(
        {"os_family": "windows", "os_image": "windows-server-2022-dc",
         "cpu": 8, "memory_gb": 32, "disk_gb": 200,
         "network": "cluster-net", "node_count": 3, "cluster": True},
        id="win2022-3node"
    ),
]


# ── Tests ─────────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("op,op_payload", ALL_PROFILE_OPS)
@pytest.mark.parametrize("vm_profile", MIXED_PROFILES)
def test_day2_all_profiles(client, vm_profile, op, op_payload,
                           unique_name, poll_request):
    """
    Auto-expanded matrix — runs for every profile × operation combination.

    Generated test IDs:
      test_day2_all_profiles[rhel9-power_off]
      test_day2_all_profiles[rhel9-snapshot]
      test_day2_all_profiles[win2022-std-power_off]  ... etc
    """
    # Step 1: Create the VM
    create_payload = {**vm_profile, "name": unique_name}
    r = client.post("/api/v1/vms", json=create_payload)
    assert r.status_code == 202, f"VM create failed: {r.text}"
    create_result = poll_request(r.json()["data"]["request_id"])
    assert create_result["status"] == "completed"

    # Step 2: Execute day-2 operation
    r = client.post(f"/api/v1/vms/{unique_name}/{op}", json=op_payload)
    assert r.status_code == 202, f"Day-2 op '{op}' failed: {r.text}"
    result = poll_request(r.json()["data"]["request_id"])
    assert result["status"] == "completed", (
        f"Day-2 '{op}' on {vm_profile['os_image']} failed: {result.get('error')}"
    )


@pytest.mark.linux_only
@pytest.mark.parametrize("op,op_payload", LINUX_OPS)
@pytest.mark.parametrize("vm_profile", LINUX_PROFILES)
def test_day2_linux_only(client, vm_profile, op, op_payload,
                         unique_name, poll_request):
    """Linux-specific day-2 ops: resize, disk_expand, migrate."""
    create_payload = {**vm_profile, "name": unique_name}
    r = client.post("/api/v1/vms", json=create_payload)
    assert r.status_code == 202
    poll_request(r.json()["data"]["request_id"])

    r = client.post(f"/api/v1/vms/{unique_name}/{op}", json=op_payload)
    assert r.status_code == 202, f"Linux op '{op}' failed: {r.text}"
    result = poll_request(r.json()["data"]["request_id"])
    assert result["status"] == "completed"

    # Extra assertions per op
    if op == "resize":
        assert result["vm"]["cpu"]       == op_payload["cpu"]
        assert result["vm"]["memory_gb"] == op_payload["memory_gb"]
    if op == "disk_expand":
        assert result["vm"]["disk_gb"] >= op_payload["disk_gb"]


@pytest.mark.windows_only
@pytest.mark.parametrize("op,op_payload", WINDOWS_OPS)
def test_day2_windows_only(client, op, op_payload, unique_name, poll_request):
    """Windows-specific day-2 ops: patch, reboot."""
    profile = {
        "os_family": "windows", "os_image": "windows-server-2022-std",
        "cpu": 4, "memory_gb": 16, "disk_gb": 100, "network": "default-net"
    }
    create_payload = {**profile, "name": unique_name}
    r = client.post("/api/v1/vms", json=create_payload)
    assert r.status_code == 202
    poll_request(r.json()["data"]["request_id"])

    r = client.post(f"/api/v1/vms/{unique_name}/{op}", json=op_payload)
    assert r.status_code == 202, f"Windows op '{op}' failed: {r.text}"
    result = poll_request(r.json()["data"]["request_id"])
    assert result["status"] == "completed"


@pytest.mark.cluster
@pytest.mark.parametrize("op,op_payload", CLUSTER_OPS)
@pytest.mark.parametrize("vm_profile", CLUSTER_PROFILES)
def test_day2_cluster_ops(client, vm_profile, op, op_payload,
                          unique_name, poll_request):
    """
    Multi-node cluster operations: failover, add_node, remove_node.
    Only runs on cluster profiles (2-node, 3-node Windows).
    """
    create_payload = {**vm_profile, "name": unique_name}
    r = client.post("/api/v1/vms", json=create_payload)
    assert r.status_code == 202
    create_result = poll_request(r.json()["data"]["request_id"])
    assert create_result["status"] == "completed"

    # remove_node only valid on 3-node clusters
    if op == "remove_node" and vm_profile["node_count"] < 3:
        pytest.skip("remove_node requires node_count >= 3")

    r = client.post(f"/api/v1/vms/{unique_name}/cluster/{op}", json=op_payload)
    assert r.status_code == 202, f"Cluster op '{op}' failed: {r.text}"
    result = poll_request(r.json()["data"]["request_id"])
    assert result["status"] == "completed"

    # Op-specific assertions
    if op == "add_node":
        expected_nodes = vm_profile["node_count"] + op_payload["node_count"]
        assert result["cluster"]["node_count"] == expected_nodes

    if op == "remove_node":
        expected_nodes = vm_profile["node_count"] - 1
        assert result["cluster"]["node_count"] == expected_nodes

    if op == "failover":
        # Primary should have moved to a different node
        assert result["cluster"]["primary_node"] != 0


@pytest.mark.xdist_group("vm-lifecycle")
class TestVmLifecycle:
    """
    Ordered lifecycle tests that must run sequentially on the same xdist worker.
    Use --dist=loadgroup to keep this class on one worker.
    """

    def test_01_create(self, client, get_payload, unique_name, poll_request):
        payload = get_payload("vm_create", extra={"name": unique_name})
        r = client.post("/api/v1/vms", json=payload)
        assert r.status_code == 202
        result = poll_request(r.json()["data"]["request_id"])
        assert result["status"] == "completed"

    def test_02_resize(self, client, get_payload, unique_name, poll_request):
        payload = get_payload("vm_resize")
        r = client.post(f"/api/v1/vms/{unique_name}/resize", json=payload)
        assert r.status_code == 202
        result = poll_request(r.json()["data"]["request_id"])
        assert result["status"] == "completed"

    def test_03_snapshot(self, client, poll_request, unique_name):
        r = client.post(f"/api/v1/vms/{unique_name}/snapshot",
                        json={"name": "lifecycle-snap"})
        assert r.status_code == 202
        result = poll_request(r.json()["data"]["request_id"])
        assert result["status"] == "completed"

    def test_04_delete(self, client, poll_request, unique_name):
        r = client.delete(f"/api/v1/vms/{unique_name}")
        assert r.status_code == 202
        result = poll_request(r.json()["data"]["request_id"])
        assert result["status"] == "completed"

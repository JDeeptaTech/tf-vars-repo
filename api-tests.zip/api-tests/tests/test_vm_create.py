"""
VM creation tests — parametrized across all profiles in the selected matrix.

Run examples:
  pytest tests/test_vm_create.py --api-url=... --token=... --env=dev --matrix=smoke
  pytest tests/test_vm_create.py --api-url=... --token=... --env=uat --matrix=linux_all -n 4
"""
import pytest
from conftest import get_matrix_params


def pytest_generate_tests(metafunc):
    """Dynamically parametrize vm_profile from the --matrix CLI arg."""
    if "vm_profile" in metafunc.fixturenames:
        registry = metafunc.config._profile_registry  # set via session fixture below
        matrix   = metafunc.config.getoption("--matrix")
        params   = get_matrix_params(registry, matrix)
        metafunc.parametrize("vm_profile", params)


# Store the registry on config so pytest_generate_tests can access it
# (fixtures are not available at collection time)
def pytest_configure(config):
    config._profile_registry = None


@pytest.fixture(scope="session", autouse=True)
def _cache_profile_registry(profile_registry, request):
    request.config._profile_registry = profile_registry


# ── Tests ─────────────────────────────────────────────────────────────────────

@pytest.mark.smoke
def test_vm_create(client, vm_profile, unique_name, poll_request):
    """
    Creates a VM for every profile in the selected matrix and polls
    until completion.

    Test IDs generated automatically:
      test_vm_create[rhel9-small]
      test_vm_create[win2022-std]
      test_vm_create[win2022-cluster-2node]  ... etc
    """
    payload = {**vm_profile, "name": unique_name}
    r = client.post("/api/v1/vms", json=payload)
    assert r.status_code == 202, f"Unexpected status: {r.status_code} — {r.text}"

    result = poll_request(r.json()["data"]["request_id"])
    assert result["status"] == "completed", (
        f"VM creation failed for profile — status: {result['status']}, "
        f"error: {result.get('error')}"
    )


@pytest.mark.smoke
def test_vm_create_returns_request_id(client, vm_profile, unique_name):
    """Response envelope must contain a request_id immediately on 202."""
    payload = {**vm_profile, "name": unique_name}
    r = client.post("/api/v1/vms", json=payload)
    assert r.status_code == 202
    body = r.json()
    assert "data" in body
    assert "request_id" in body["data"], "Missing request_id in response"


@pytest.mark.cluster
def test_multinode_all_nodes_registered(client, unique_name, poll_request, profile_registry):
    """
    Multi-node VMs must register the correct number of nodes,
    all in 'running' state.
    """
    cluster_profiles = [
        (name, profile)
        for name, profile in profile_registry["profiles"].items()
        if profile.get("cluster") is True
    ]

    if not cluster_profiles:
        pytest.skip("No cluster profiles defined")

    for name, profile in cluster_profiles:
        payload = {**profile, "name": f"{unique_name}-{name[:6]}"}
        r = client.post("/api/v1/vms", json=payload)
        assert r.status_code == 202, f"Cluster create failed for {name}: {r.text}"

        result = poll_request(r.json()["data"]["request_id"])
        assert result["status"] == "completed"

        nodes = result.get("nodes", [])
        assert len(nodes) == profile["node_count"], (
            f"Profile {name}: expected {profile['node_count']} nodes, got {len(nodes)}"
        )
        assert all(n["status"] == "running" for n in nodes), (
            f"Not all nodes running for {name}: {nodes}"
        )


@pytest.mark.prod_only
@pytest.mark.regression
def test_vm_create_placement_policy(client, vm_profile, unique_name, poll_request):
    """
    Prod only: verifies placement engine assigned the VM to the
    correct cluster/datastore based on profile tags.
    """
    payload = {**vm_profile, "name": unique_name}
    r = client.post("/api/v1/vms", json=payload)
    assert r.status_code == 202

    result = poll_request(r.json()["data"]["request_id"])
    assert result["status"] == "completed"
    assert "placement" in result, "No placement data in response"
    assert result["placement"]["cluster"] is not None
